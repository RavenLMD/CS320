package contact;

public class Contact {
	//Contents of class
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//Constructor
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		//Throws exception if any values are null or are larger than allowed (or not 10 digits in the case of the phone variable)
		if(contactID.length() > 10 || contactID == null || firstName.length() > 10 || firstName == null || lastName.length() > 10 || 
		   lastName == null || phone.length() != 10 || phone == null || address.length() > 30 || address == null) {
			throw new IllegalArgumentException("Invalid input");
		}
		
		//If no exception was thrown, sets all variables
		this.contactID=contactID;
		this.firstName=firstName;
		this.lastName=lastName;
		this.phone=phone;
		this.address=address;
	}
	
	//Getters and Setters
	
	//Getters
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	//Setters
	//contactID is not updatable, as such, there is no contactID setter
	public void setFirstName(String newFirstName) {
		this.firstName = newFirstName;
	}
	
	public void setLastName(String newLastName) {
		this.lastName = newLastName;
	}
	public void setPhone(String newPhone) {
		this.phone = newPhone;
	}
	
	public void setAddress(String newAddress) {
		this.address = newAddress;
	}
}
