package contact;

import java.util.ArrayList;

public class ContactService {
	//ID variables that allow for interaction with contact variables based on their unique IDs
	public static String foundID; //Variable used for contact searching by ID
	public static int foundIDLocation; //Contact index by ID
	//Contacts array
	public static ArrayList<Contact> contacts = new ArrayList<Contact>();


	//Finds index of contact with given contactID
	public static int searchID(String ID) {
		int foundIDLocation = -1;
		for(int i = 0;  i <= contacts.size(); i++){
			
			//If ID not found
			if((foundID != ID && i == contacts.size()) || contacts.size() == 0) {
				throw new IllegalArgumentException("ID not found");
			}
			
			foundID = contacts.get(i).getContactID();

			//If ID found, delete appointment
			if(foundID == ID) {
				foundIDLocation = i;
				i = contacts.size();
			}	
		}
		return foundIDLocation;
	}

	//Creates new contact
	public static void addContact(String contactID, String firstName, String lastName, String phone, String address) {
		Contact contact = new Contact(contactID, firstName, lastName, phone, address);		
		contacts.add(contact);
	}

	//Deletes contact
	public static void deleteContact(String ID) {
		foundIDLocation = searchID(ID);
		contacts.remove(foundIDLocation);
	}

	//Changes contact variables based upon contact IDs if IDs are found in the contacts array. IF the given ID is not found, the searchID function throws an exception
	public static void changeFirstName(String ID, String newFirstName) {
		foundIDLocation = searchID(ID);
		contacts.get(foundIDLocation).setFirstName(newFirstName);
	}

	public static void changeLastName(String ID, String newLastName) {
		foundIDLocation = searchID(ID);
		contacts.get(foundIDLocation).setLastName(newLastName);
	}

	public static void changePhone(String ID, String newPhone) {
		foundIDLocation = searchID(ID);
		contacts.get(foundIDLocation).setPhone(newPhone);
	}
	public static void changeAddress(String ID, String newAddress) {
		foundIDLocation = searchID(ID);
		contacts.get(foundIDLocation).setAddress(newAddress);
	}

}
